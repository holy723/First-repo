import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const categories = [
  ["Phones & Gadgets", "phones-gadgets"],
  ["Electronics", "electronics"],
  ["Fashion", "fashion"],
  ["Food & Groceries", "food-groceries"],
  ["Home & Furniture", "home-furniture"],
  ["Beauty & Health", "beauty-health"],
  ["Transport", "transport"],
  ["Jobs & Services", "jobs-services"],
  ["Other", "other"]
] as const;

async function main() {
  for (const [name, slug] of categories) {
    await prisma.category.upsert({
      where: { slug },
      update: {},
      create: { name, slug }
    });
  }

  const category = await prisma.category.findUniqueOrThrow({
    where: { slug: "phones-gadgets" }
  });

  const user = await prisma.user.upsert({
    where: { email: "demo@naijadeal.local" },
    update: {},
    create: {
      name: "NaijaDeal Demo",
      username: "naijadealdemo",
      email: "demo@naijadeal.local",
      role: "SELLER",
      verified: true
    }
  });

  await prisma.sellerProfile.upsert({
    where: { userId: user.id },
    update: {},
    create: {
      userId: user.id,
      businessName: "NaijaDeal Demo Store",
      location: "Lagos",
      verified: true
    }
  });

  const existing = await prisma.deal.count();
  if (existing === 0) {
    await prisma.deal.create({
      data: {
        title: "iPhone 11 128GB",
        slug: "iphone-11-128gb-demo",
        description: "Demo listing for local development.",
        originalPrice: 450000,
        dealPrice: 380000,
        discountPercentage: 16,
        categoryId: category.id,
        sellerUserId: user.id,
        sellerId: (await prisma.sellerProfile.findUniqueOrThrow({ where: { userId: user.id } })).id,
        location: "Lagos",
        condition: "Used",
        images: [],
        status: "ACTIVE"
      }
    });
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
