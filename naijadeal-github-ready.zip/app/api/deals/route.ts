import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { discountPct, slugify } from "@/lib/utils";
import { z } from "zod";

const schema = z.object({
  title: z.string().trim().min(3).max(80),
  description: z.string().trim().max(500).optional(),
  originalPrice: z.number().int().positive(),
  dealPrice: z.number().int().positive(),
  categoryId: z.string().min(1),
  sellerUserId: z.string().min(1),
  location: z.string().trim().max(100).optional(),
  condition: z.string().trim().max(50).optional(),
  externalLink: z.string().url().optional(),
  images: z.array(z.string().url()).max(10).default([]),
  expiresAt: z.string().datetime().optional()
});

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search")?.trim() ?? "";
  const categoryId = searchParams.get("categoryId");
  const location = searchParams.get("location")?.trim();

  const deals = await prisma.deal.findMany({
    where: {
      status: "ACTIVE",
      ...(categoryId ? { categoryId } : {}),
      ...(location ? { location: { contains: location, mode: "insensitive" } } : {}),
      ...(search
        ? {
            OR: [
              { title: { contains: search, mode: "insensitive" } },
              { description: { contains: search, mode: "insensitive" } }
            ]
          }
        : {})
    },
    include: {
      category: true,
      sellerUser: { select: { name: true, username: true, verified: true } }
    },
    orderBy: { createdAt: "desc" },
    take: 50
  });

  return NextResponse.json({ success: true, deals });
}

export async function POST(request: NextRequest) {
  try {
    const data = schema.parse(await request.json());

    if (data.dealPrice > data.originalPrice) {
      return NextResponse.json(
        { success: false, error: "Deal price cannot be higher than original price." },
        { status: 400 }
      );
    }

    const [category, seller] = await Promise.all([
      prisma.category.findUnique({ where: { id: data.categoryId } }),
      prisma.user.findUnique({ where: { id: data.sellerUserId } })
    ]);

    if (!category || !seller) {
      return NextResponse.json(
        { success: false, error: "Category or seller was not found." },
        { status: 400 }
      );
    }

    const baseSlug = slugify(data.title);
    const deal = await prisma.deal.create({
      data: {
        title: data.title,
        slug: `${baseSlug}-${Date.now().toString(36)}`,
        description: data.description || null,
        originalPrice: data.originalPrice,
        dealPrice: data.dealPrice,
        discountPercentage: discountPct(data.originalPrice, data.dealPrice),
        categoryId: data.categoryId,
        sellerUserId: data.sellerUserId,
        location: data.location || null,
        condition: data.condition || null,
        externalLink: data.externalLink || null,
        images: data.images,
        expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
        status: "PENDING_REVIEW"
      }
    });

    return NextResponse.json({ success: true, deal }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: "Invalid deal information.", details: error.flatten() },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: "Unable to create deal." },
      { status: 500 }
    );
  }
}
