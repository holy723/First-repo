import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;

  const deal = await prisma.deal.findUnique({
    where: { slug },
    include: {
      category: true,
      seller: true,
      sellerUser: {
        select: { id: true, name: true, username: true, verified: true }
      }
    }
  });

  if (!deal) {
    return NextResponse.json({ success: false, error: "Deal not found." }, { status: 404 });
  }

  if (deal.expiresAt && deal.expiresAt < new Date() && deal.status === "ACTIVE") {
    await prisma.deal.update({
      where: { id: deal.id },
      data: { status: "EXPIRED" }
    });
    return NextResponse.json({ success: false, error: "This deal has expired." }, { status: 410 });
  }

  return NextResponse.json({ success: true, deal });
}
