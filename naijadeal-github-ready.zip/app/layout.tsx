import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NaijaDeal — deals people are talking about",
  description: "Discover and share deals across Nigeria."
};

export default function RootLayout({
  children
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
