import { prisma } from "@/lib/prisma";
import DealBrowser from "@/components/DealBrowser";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [deals, categories] = await Promise.all([
    prisma.deal.findMany({
      where: { status: "ACTIVE" },
      include: {
        category: true,
        sellerUser: { select: { name: true, username: true, verified: true } }
      },
      orderBy: { createdAt: "desc" },
      take: 100
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } })
  ]);

  const safeDeals = deals.map((d) => ({
    id: d.id,
    title: d.title,
    slug: d.slug,
    description: d.description,
    originalPrice: d.originalPrice,
    dealPrice: d.dealPrice,
    discountPercentage: d.discountPercentage,
    location: d.location,
    category: d.category.name,
    seller: d.sellerUser.name,
    verified: d.sellerUser.verified,
    createdAt: d.createdAt.toISOString(),
    externalLink: d.externalLink
  }));

  return (
    <DealBrowser
      initialDeals={safeDeals}
      categories={categories.map((c) => c.name)}
    />
  );
}
