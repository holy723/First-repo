"use client";

import { useMemo, useState } from "react";
import { naira } from "@/lib/utils";

type Deal = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  originalPrice: number;
  dealPrice: number;
  discountPercentage: number;
  location: string | null;
  category: string;
  seller: string;
  verified: boolean;
  createdAt: string;
  externalLink: string | null;
};

const defaultCategories = [
  "All",
  "Phones & Gadgets",
  "Electronics",
  "Fashion",
  "Food & Groceries",
  "Home & Furniture",
  "Beauty & Health",
  "Transport",
  "Jobs & Services",
  "Other"
];

export default function DealBrowser({
  initialDeals,
  categories
}: {
  initialDeals: Deal[];
  categories: string[];
}) {
  const [deals, setDeals] = useState(initialDeals);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [open, setOpen] = useState(false);

  const chips = ["All", ...categories.filter((c) => c !== "All")];

  const visible = useMemo(() => {
    let list = [...deals];

    if (category !== "All") list = list.filter((d) => d.category === category);

    const q = search.toLowerCase().trim();
    if (q) {
      list = list.filter((d) =>
        [d.title, d.description ?? "", d.seller, d.category, d.location ?? ""]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }

    if (sort === "discount") list.sort((a, b) => b.discountPercentage - a.discountPercentage);
    if (sort === "price") list.sort((a, b) => a.dealPrice - b.dealPrice);
    if (sort === "newest") list.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));

    return list;
  }, [deals, category, search, sort]);

  function addLocalDeal(deal: Deal) {
    setDeals((current) => [deal, ...current]);
  }

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <div>
            <div className="wordmark">Naija<span className="deal">Deal</span></div>
            <div className="tagline">Wetin dey cheap for market today — post am, share am.</div>
          </div>
          <button className="post-btn" onClick={() => setOpen(true)}>+ Post a deal</button>
        </div>
      </header>

      <section className="controls">
        <input
          className="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search deals, stores, categories…"
        />
        <select className="sort" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">Newest first</option>
          <option value="discount">Biggest discount</option>
          <option value="price">Cheapest price</option>
        </select>
      </section>

      <section className="chips">
        {(chips.length ? chips : defaultCategories).map((c) => (
          <button
            key={c}
            className={`chip ${category === c ? "active" : ""}`}
            onClick={() => setCategory(c)}
          >
            {c}
          </button>
        ))}
      </section>

      <main>
        <p className="status">{visible.length} {visible.length === 1 ? "deal" : "deals"} right now</p>
        <div className="grid">
          {visible.length === 0 ? (
            <div className="empty">
              <strong>No deal here yet</strong>
              <div>Be the first to post one for this category.</div>
            </div>
          ) : (
            visible.map((d) => (
              <article className="card" key={d.id}>
                <div className="card-top">
                  <h2>{d.title}</h2>
                  {d.discountPercentage > 0 && (
                    <span className="badge">-{d.discountPercentage}%</span>
                  )}
                </div>
                <div className="meta">
                  {d.seller} {d.verified ? "✓" : ""} · {d.category}
                  {d.location ? ` · ${d.location}` : ""}
                </div>
                {d.description && <div className="desc">{d.description}</div>}
                <div>
                  <span className="price">{naira(d.dealPrice)}</span>
                  {d.originalPrice > d.dealPrice && (
                    <span className="was">{naira(d.originalPrice)}</span>
                  )}
                </div>
                {d.externalLink && (
                  <a className="deal-link" href={d.externalLink} target="_blank" rel="noreferrer">
                    Go to deal →
                  </a>
                )}
              </article>
            ))
          )}
        </div>
      </main>

      <PostDealModal open={open} onClose={() => setOpen(false)} onCreated={addLocalDeal} />
    </>
  );
}

function PostDealModal({
  open,
  onClose,
  onCreated
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (deal: Deal) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setMessage("");

    const form = new FormData(e.currentTarget);
    const body = {
      title: String(form.get("title") || ""),
      description: String(form.get("description") || ""),
      originalPrice: Number(form.get("originalPrice")),
      dealPrice: Number(form.get("dealPrice")),
      categoryId: String(form.get("categoryId") || ""),
      sellerUserId: String(form.get("sellerUserId") || ""),
      location: String(form.get("location") || ""),
      externalLink: String(form.get("externalLink") || "") || undefined
    };

    try {
      const res = await fetch("/api/deals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Something no work.");

      setMessage("Deal submitted for review.");
      setTimeout(onClose, 700);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Something no work.");
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;

  return (
    <div className="modal open" onMouseDown={(e) => e.currentTarget === e.target && onClose()}>
      <div className="dialog">
        <h2>Post a deal</h2>
        <p>Give other people the gist. Keep am short and correct.</p>

        <form onSubmit={submit}>
          <div className="field">
            <label>What be the deal?</label>
            <input name="title" maxLength={80} required placeholder="e.g. 43&quot; Smart TV, 30% off" />
          </div>

          <div className="two">
            <div className="field">
              <label>Original price (₦)</label>
              <input name="originalPrice" type="number" min="1" required />
            </div>
            <div className="field">
              <label>Deal price (₦)</label>
              <input name="dealPrice" type="number" min="1" required />
            </div>
          </div>

          <div className="field">
            <label>Category ID</label>
            <input name="categoryId" required placeholder="Paste the category ID from your database" />
          </div>

          <div className="field">
            <label>Demo seller user ID</label>
            <input name="sellerUserId" required placeholder="Paste a user ID from your database" />
          </div>

          <div className="field">
            <label>Location</label>
            <input name="location" placeholder="Lagos, Ikeja" />
          </div>

          <div className="field">
            <label>Description</label>
            <textarea name="description" maxLength={500} />
          </div>

          <div className="field">
            <label>Buy link (optional)</label>
            <input name="externalLink" type="url" placeholder="https://…" />
          </div>

          <p className="msg">{message}</p>

          <div className="actions">
            <button className="secondary" type="button" onClick={onClose}>Cancel</button>
            <button className="primary" type="submit" disabled={busy}>
              {busy ? "Posting…" : "Post deal"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
