export function naira(value: number) {
  return `₦${Number(value).toLocaleString("en-NG")}`;
}

export function discountPct(originalPrice: number, dealPrice: number) {
  if (!originalPrice || originalPrice <= 0) return 0;
  return Math.max(
    0,
    Math.round(((originalPrice - dealPrice) / originalPrice) * 100)
  );
}

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}
