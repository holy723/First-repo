# NaijaDeal 🇳🇬

A Nigeria-first community marketplace for discovering and sharing deals.

## Stack

- Next.js + React + TypeScript
- PostgreSQL + Prisma
- Zod validation
- Mobile-first responsive UI

## Local setup

1. Install Node.js 20+.
2. Create a PostgreSQL database.
3. Copy `.env.example` to `.env`.
4. Set `DATABASE_URL`.
5. Install dependencies:

```bash
npm install
```

6. Generate Prisma client:

```bash
npm run db:generate
```

7. Create/update the database:

```bash
npm run db:push
```

8. Seed categories and demo deals:

```bash
npm run db:seed
```

9. Start development:

```bash
npm run dev
```

Open http://localhost:3000.

## GitHub safety

Never commit `.env`, passwords, database URLs containing passwords, payment secrets, or API keys. `.gitignore` already excludes `.env`.

## Production

Before accepting real users or money, add production authentication/session management, object-storage image uploads, rate limiting, moderation workflows, verified payment webhooks, monitoring, backups, and legal/compliance review. The included posting API intentionally uses a development/demo `sellerUserId` until authentication is connected.

## Ownership

The source code is portable and does not require Claude at runtime. Keep GitHub, domain, hosting, database, storage, payment, email/SMS and analytics accounts under accounts you control.
